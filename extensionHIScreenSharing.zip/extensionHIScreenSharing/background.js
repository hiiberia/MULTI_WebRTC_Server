var desktopMediaRequestId;

// when connect event is triggered from init.js
chrome.runtime.onConnect.addListener( function( port ){
	// listen for messages from the port
    port.onMessage.addListener( function( message ){
		
		if(message.text == "startShare"){
			desktopMediaRequestId = chrome.desktopCapture.chooseDesktopMedia(message.shareTypes, port.sender.tab, function( id ){
				var response = {
					"answer": 1,
					"state": "completed",
					//"requestId": message.requestId,
					"streamId": id || undefined
				};
				// send back a "completed" answer on the port
				port.postMessage( response );
			
			
			} );
		}
		
		if(message.text == "hideShareDialog"){
			var response = {
					"answer": 1,
					"state": "cancelingChooseDesktopMedia",
					"desktopMediaRequestId": 0
				};
			port.postMessage(response);
			
			chrome.desktopCapture.cancelChooseDesktopMedia(desktopMediaRequestId);
			
			response.state = "canceledChooseDesktopMedia";
			response.desktopMediaRequestId = desktopMediaRequestId;
			port.postMessage(response);
		}

	} );
} );
