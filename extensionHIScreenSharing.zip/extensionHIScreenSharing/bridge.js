// open a port to communicate with background
var port = chrome.runtime.connect();
// listen for messages from webpage and forward them to the background, through the previously opened port
window.addEventListener( 'message', function ( event ){
    if ( event.source != window || !event.data ){
        return;
    }
    // prevent to return answer to the background
    if( event.data.answer ){
        return;
    }
    
    if(event.data.messg){
    	if(event.data.messg == "startShareHI"){
    		var json = {
    			text : "startShare",
    			shareTypes: event.data.shareTypes
    		};
    		port.postMessage(json);
    	}
    	if(event.data.messg == "hideShareDialog"){
    		var json = {
    			text : "hideShareDialog",
    		};
    		port.postMessage(json);
    	}
    }
    
} );

//Extension installed
var isInstalledNode = document.createElement('div');
isInstalledNode.id = 'extension-is-installed';
document.body.appendChild(isInstalledNode);

/*var dataInstalled = {"answer":1,"state":"extension_installed"};
window.postMessage( dataInstalled, '*' );*/
///

// listen for messages from background and forward them to the webpage
port.onMessage.addListener( function( data ){
    window.postMessage( data, '*' );
} );
